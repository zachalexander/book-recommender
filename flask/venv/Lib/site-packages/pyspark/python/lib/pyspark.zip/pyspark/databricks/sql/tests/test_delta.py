#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2019 Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

import os
import time
import unittest

from pyspark.sql import DataFrame, Row
from pyspark.sql.functions import col, count, lit
from pyspark.sql.tests import ReusedSQLTestCase


class MetadataQueryFuzzTests(ReusedSQLTestCase):

    @classmethod
    def setUpClass(cls):
        ReusedSQLTestCase.setUpClass()
        seed = os.getenv('DELTA_FUZZ_TEST_SEED', int(round(time.time() * 1000)))
        print("using seed %s" % seed)
        cls.seed = seed
        cls.NUM_ITERATIONS = 3

    def assertEq(self, given, expected):
        self.assertEqual(len(given), len(expected),
                         "The answer returned a different number of rows (%s) " % len(given) +
                         "than the expected result (%s)" % (len(expected)))
        for result_row in given:
            self.assertTrue(result_row in expected,
                            "Row: %s\nnot found in result:\n%s" %
                            (repr(result_row), "\n".join([repr(e) for e in expected])))

    def assertContainsMetadataOptimization(self, df, is_empty):
        return self.spark._jvm \
            .__getattr__('com.databricks.sql.transaction.tahoe.stats.' +
                         'random.DeltaMetadataQueryFuzzSuite$') \
            .__getattr__('MODULE$') \
            .assertContainsMetadataOptimization(df, is_empty)

    def assertNoMetadataOptimization(self, df, is_empty):
        return self.spark._jvm \
            .__getattr__('com.databricks.sql.transaction.tahoe.stats.' +
                         'random.DeltaMetadataQueryFuzzSuite$') \
            .__getattr__('MODULE$') \
            .assertNoMetadataOptimization(df, is_empty)

    def run_randomized_test(self, rqg):
        rqg.generateData()
        rqg.generateQuery()

        maybe_optimized = DataFrame(rqg.planQuery(True), self.spark)
        not_optimized = DataFrame(rqg.planQuery(False), self.spark)

        self.assertEq(maybe_optimized.collect(), not_optimized.collect())

    def create_rqg(self, num_data_columns, num_partition_columns, is_empty=False):
        if is_empty:
            rows_per_file = 0
            files_per_partition = 0
        else:
            rows_per_file = 100
            files_per_partition = 10

        return self.spark._jvm \
            .__getattr__('com.databricks.sql.transaction.tahoe.stats.' +
                         'random.DeltaMetadataQueryFuzzSuite$') \
            .__getattr__('MODULE$') \
            .createRQG(self.seed, num_data_columns, num_partition_columns, rows_per_file,
                       files_per_partition)

    def edge_mode_enabled(self):
        return self.spark._jvm \
            .__getattr__('com.databricks.spark.DatabricksEdgeConfigs$') \
            .__getattr__('MODULE$') \
            .edgeModeEnabled()

    def test_partitioned_table_random(self):
        if self.edge_mode_enabled():
            for i in range(self.NUM_ITERATIONS):
                rqg = self.create_rqg(4, 1)
                self.run_randomized_test(rqg)

    def test_unpartitioned_table_random(self):
        if self.edge_mode_enabled():
            for i in range(self.NUM_ITERATIONS):
                rqg = self.create_rqg(4, 0)
                self.run_randomized_test(rqg)

    def test_empty_partitioned_table_random(self):
        if self.edge_mode_enabled():
            for i in range(self.NUM_ITERATIONS):
                rqg = self.create_rqg(4, 1, True)
                self.run_randomized_test(rqg)

    def test_empty_unpartitioned_table_random(self):
        if self.edge_mode_enabled():
            for i in range(self.NUM_ITERATIONS):
                rqg = self.create_rqg(4, 0, True)
                self.run_randomized_test(rqg)

    def test_empty_unpartitioned_table(self):
        if self.edge_mode_enabled():
            spark = self.spark
            tbl = "test_table"
            spark.sql("CREATE TABLE %s (id bigint, part string) USING delta" % tbl)
            try:
                # explicit global aggregations
                emptyAgg = {}
                self.assertEq(spark.table(tbl).agg(emptyAgg).collect(), [Row()])
                self.assertEq(spark.table(tbl).groupBy().agg(emptyAgg).collect(), [Row()])
                self.assertEq(spark.table(tbl).groupBy().agg(count("*").alias('cnt')).collect(),
                              [Row(cnt=0)])
                self.assertEq(spark.table(tbl).dropDuplicates().agg(emptyAgg).collect(), [Row()])
                self.assertEq(spark.table(tbl).dropDuplicates().groupBy().agg(emptyAgg).collect(),
                              [Row()])
                self.assertEq(spark.table(tbl).dropDuplicates().groupBy()
                              .agg(count("*").alias('cnt')).collect(),
                              [Row(cnt=0)])

                # global aggregation is converted to grouping aggregation:
                self.assertEqual(spark.table(tbl).dropDuplicates().count(), 0)
            finally:
                spark.sql("DROP TABLE %s" % tbl)

    def test_empty_partitioned_table(self):
        if self.edge_mode_enabled():
            spark = self.spark
            tbl = "test_table"
            spark.sql("CREATE TABLE %s (id bigint, part string) USING delta PARTITIONED BY (part)" %
                      tbl)
            try:
                # explicit global aggregations
                emptyAgg = {}
                self.assertEq(spark.table(tbl).agg(emptyAgg).collect(), [Row()])
                self.assertEq(spark.table(tbl).groupBy().agg(emptyAgg).collect(), [Row()])
                self.assertEq(spark.table(tbl).groupBy().agg(count("*").alias('cnt')).collect(),
                              [Row(cnt=0)])
                self.assertEq(spark.table(tbl).dropDuplicates().agg(emptyAgg).collect(), [Row()])
                self.assertEq(spark.table(tbl).dropDuplicates().groupBy().agg(emptyAgg).collect(),
                              [Row()])
                self.assertEq(spark.table(tbl).dropDuplicates().groupBy()
                              .agg(count("*").alias('cnt')).collect(),
                              [Row(cnt=0)])

                # global aggregation is converted to grouping aggregation:
                self.assertEqual(spark.table(tbl).dropDuplicates().count(), 0)
            finally:
                spark.sql("DROP TABLE %s" % tbl)

    def test_empty_partition_count(self):
        if self.edge_mode_enabled():
            spark = self.spark
            tbl = "test_table"
            spark.range(10).withColumn("part", col('id') % lit(2)).write.format("delta") \
                .partitionBy("part").saveAsTable(tbl)
            try:
                query1 = "select count(*) from %s where part = 3" % tbl
                self.assertEqual(spark.sql(query1).first(), Row(0))
                query2 = "select max(id), min(id) from %s where part = 3" % tbl
                self.assertEqual(spark.sql(query2).first(), Row(None, None))
            finally:
                spark.sql("DROP TABLE %s" % tbl)


if __name__ == "__main__":
    from pyspark.databricks.sql.tests.test_delta import *

    try:
        import xmlrunner
        unittest.main(testRunner=xmlrunner.XMLTestRunner(
            output='target/test-reports', verbosity=2), verbosity=2)
    except ImportError:
        unittest.main(verbosity=2)
