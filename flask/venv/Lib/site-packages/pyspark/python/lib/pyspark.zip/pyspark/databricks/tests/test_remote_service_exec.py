#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2019 Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from contextlib import contextmanager
import sys
import unittest

from pyspark.testing.utils import PySparkTestCase
from pyspark.sql import SparkSession

if sys.version >= "3":
    from io import StringIO
else:
    from StringIO import StringIO


class RemoteServiceExecTests(PySparkTestCase):
    def test_explain(self):
        session = SparkSession.builder.getOrCreate()
        session.conf.set("spark.databricks.service.client.enabled", "true")
        session.conf.set("spark.databricks.service.address", "localhost")
        dbconnect_df = session.range(10)
        with captured_output() as (out, err):
            dbconnect_df.explain()
        remote_output = out.getvalue().strip()

        session.conf.set("spark.databricks.service.client.enabled", "false")
        local_df = session.range(10)
        with captured_output() as (out2, err2):
            local_df.explain()
        local_output = out2.getvalue().strip()
        self.assertEqual(remote_output, local_output)


@contextmanager
def captured_output():
    new_out, new_err = StringIO(), StringIO()
    old_out, old_err = sys.stdout, sys.stderr
    try:
        sys.stdout, sys.stderr = new_out, new_err
        yield sys.stdout, sys.stderr
    finally:
        sys.stdout, sys.stderr = old_out, old_err

if __name__ == "__main__":
    from pyspark.databricks.tests.test_remote_service_exec import *
    try:
        import xmlrunner
        unittest.main(testRunner=xmlrunner.XMLTestRunner(output='target/test-reports'), verbosity=2)
    except ImportError:
        unittest.main(verbosity=2)
